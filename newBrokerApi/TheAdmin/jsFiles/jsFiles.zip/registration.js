document.addEventListener('DOMContentLoaded', function () {
  const registerForm = document.getElementById('register_val');
  const submitBtn = document.getElementById('btn');
  const referral = document.getElementById('referral');
  const wholereferal = document.getElementById('wholereferal');
  const getUrl = getParamDetailsFromLinks();
  const gottenparam = getUrl.u ?? null;

  if (gottenparam !== null) {
    referral.value = gottenparam;
  } else {
    referral.value = 'null';
    wholereferal.style.display = 'none';
  }

  const checkFormValidity = () => {
    const inputs = registerForm.querySelectorAll(
      'input[type="text"], input[type="email"], input[type="date"], input[type="password"], select',
    );

    let allFilled = Array.from(inputs).every(
      (input) => input.value.trim() !== '',
    );
    let termsAccepted = checkbox.checked;

    submitBtn.disabled = !(allFilled && termsAccepted);
  };

  registerForm.querySelectorAll('input, select').forEach((input) => {
    input.addEventListener('input', checkFormValidity);
  });

  registerForm.addEventListener('submit', function (e) {
    e.preventDefault();
    setLoaderWithCustom(submitBtn, 'Loading..');
    checkFormValidity();

    if (!submitBtn.disabled) {
      const data = new FormData(registerForm);
      axios
        .post('../newApi/api/task/regUser', data)
        .then(function (response) {
          if (response.status === 201) {
            const message = response.data.message.status;
            const userMail = response.data.message.email;
            if (message === 'true') {
              Toasty.showToast(
                'success',
                'your account registeration is successful',
              );
            }
          }
        })
        .catch(function (error) {
          if (error.response && error.response.status === 422) {
            const message = error.response.data.errors[0];
            Toasty.showToast('danger', message);
          }
        })
        .finally(function () {
          unSetLoader(submitBtn, 'Sign up');
        });
    }
  });

  // Initial check on load
  checkFormValidity();
});
