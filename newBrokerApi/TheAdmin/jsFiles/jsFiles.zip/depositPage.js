document.addEventListener('DOMContentLoaded', function () {
  const form = document.querySelector('#form');
  const amount = document.querySelector("#outlined");
  const button = document.querySelector("#btn");
  const wallet = document.querySelector("#refUrlB");
  const method = document.querySelector("select[name='payment_mode']");
  const depAmt = document.querySelectorAll("#depAmt");
  const coinVal = document.querySelector("#coinVal");
  const coinTy = document.querySelector("#coinTy");
  const paymo = document.querySelector("#paymo");
  const refUrl = document.querySelector("#refUrl");
  const coinImg = document.querySelector("#coinImg");
  const firstFund = document.querySelector("#firstFund");
  const seconfDetail = document.querySelector("#seconfDetail");
  const loaderOverlay = document.querySelector("#loaderOverlay");
  const Send = document.querySelector("#Send");
  const note = document.querySelector("#note");
  const thirdDetail = document.querySelector("#thirdDetail");
  const currency = localStorage.getItem('currency')
  seconfDetail.style.visibility = "hidden";
  thirdDetail.style.visibility = "hidden";
  loaderOverlay.style.display = "none";
  let price, symbol, bitcoinFraction;

  const getUrl = getParamDetailsFromLinks();
  const gottenparam = getUrl.plan ?? null;

  if (gottenparam !== null) {
    try {
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        setLoaderWithCustom(button, 'Loading..');
        setTimeout(() => {
          if (amount.value === '') {
            Toasty.showToast(
              'danger',
              'amount field cannot be empty. Please enter an amount to deposit',
            );
            unSetLoader(button, 'Fund Now');
          }
          if (method.value === '') {
            Toasty.showToast(
              'danger',
              'Deposit field cannot be empty. Please choose a method  to deposit',
            );
            unSetLoader(button, 'Fund Now');
          }
          const depositMethod = method.value;
          coinTy.textContent = `${method.value.toUpperCase()} ADDRESS`;
          paymo.value = `${method.value.toUpperCase()}`;
          axios
            .post('../newApi/api/task/fetchWallet')
            .then((response) => {
              if (response.status === 201) {
                const readResult = response.data.message;
                const { bitcoin, ethereum, tether } = readResult;
                if (depositMethod === 'Ethereum') {
                  // refUrl.textContent = ethereum;
                  // refUrl.innerHTML = ethereum;
                  wallet.value = ethereum;
                  coinImg.src = "ethereum.svg";
                  qrCoin.src = `https://quickchart.io/qr?text=${ethereum}`;
                }
                if (depositMethod === 'Bitcoin') {
                  // refUrl.textContent = bitcoin;
                  // refUrl.innerHTML = bitcoin;
                  wallet.value = bitcoin;
                  coinImg.src = "bitcoin.svg";
                  qrCoin.src = `https://quickchart.io/qr?text=${bitcoin}`;
                }
                if (depositMethod === 'Tether') {
                  // refUrl.textContent = tether;
                  // refUrl.innerHTML = tether;
                  wallet.value = tether;
                  coinImg.src = "tether-usdt-logo.svg";
                  qrCoin.src = `https://quickchart.io/qr?text=${tether}`;
                }
                coins = depositMethod;
                async function getCryptoData(cryptoSymbol) {
                  try {
                    const response = await fetch(
                      `https://api.coingecko.com/api/v3/coins/${cryptoSymbol}`,
                    );
                    const data = await response.json();
                    return data;
                  } catch (error) {
                    console.error('Error fetch3ing cryptocurrency data:', error);
                  }
                }
                // Example usage
                const cryptoSymbol = coins.toLowerCase();
                const usdAmount = amount.value;
                getCryptoData(cryptoSymbol).then((data) => {
                  price = data.market_data.current_price.usd;
                  symbol = data.name;
                  bitcoinFraction = usdAmount / price;
                  depAmt.forEach(e => {
                    e.textContent = ` ${currency}${usdAmount}`;
                  })
                  note.textContent = `Please ensure your payment was made to this ${cryptoSymbol} Wallet ${wallet.value}`;
                  coinVal.textContent = `with a value of ${bitcoinFraction.toFixed(4)} ${data.symbol.toUpperCase()} `;
                  const sessionGetUserID = localStorage.getItem('uId');
                  const requestData = {
                    cryptovalue: bitcoinFraction,
                    cryptoAmt: usdAmount,
                    netWork: symbol,
                    sessionGetUserID: sessionGetUserID,
                    companyWallet: wallet.value,
                    selectedPlan: gottenparam
                  };
                  axios
                    .post('../newApi/api/task/plandepositPage', requestData)
                    .then((response) => {
                      if (response.status === 201) {
                        const readResult = response.data.message;
                        depositId = readResult.userId;
                        if (readResult.message === 'true') {
                          // Toasty.showToast(
                          //   'success',
                          //   `your deposit has been recorded you are to pay ${usdAmount} ${currency} in value ${bitcoinFraction.toFixed(2)} ${symbol.toUpperCase()}`,
                          // );
                          unSetLoader(button, 'Fund Now');
                          firstFund.style.display = 'none';
                          loaderOverlay.style.display = 'flex';
                          setTimeout(() => {
                            loaderOverlay.style.display = 'none';
                          }, 6000);
                          seconfDetail.style.visibility = 'visible';
                        }
                      }
                    })
                    .catch((error) => {
                      if (error.response && error.response.status === 422) {
                        const message = error.response.data.errors[0];
                        Toasty.showToast('danger', message);
                      }
                    })
                });
              }
            })
            .catch((error) => {
              if (error.response && error.response.status === 422) {
                const message = error.response.data.errors[0];
                Toasty.showToast('danger', message);
              }
            }).finally(function () {
              unSetLoader(button, 'Fund Now');
            })
        });
      }, 3000);
    } catch (error) {
      console.log(error);

    }
  } else {
    try {
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        setLoaderWithCustom(button, 'Loading..');
        setTimeout(() => {

          if (amount.value === '') {
            Toasty.showToast(
              'danger',
              'amount field cannot be empty. Please enter an amount to deposit',
            );
            unSetLoader(button, 'Fund Now');

          }
          if (method.value === '') {
            Toasty.showToast(
              'danger',
              'Deposit field cannot be empty. Please choose a method  to deposit',
            );
            unSetLoader(button, 'Fund Now');
          }

          const depositMethod = method.value;

          coinTy.textContent = `${method.value.toUpperCase()} ADDRESS`;
          paymo.value = `${method.value.toUpperCase()}`;
          axios
            .post('../newApi/api/task/fetchWallet')
            .then((response) => {
              if (response.status === 201) {
                const readResult = response.data.message;
                const { bitcoin, ethereum, tether } = readResult;

                if (depositMethod === 'Ethereum') {
                  // refUrl.textContent = ethereum;
                  // refUrl.innerHTML = ethereum;
                  wallet.value = ethereum;
                  coinImg.src = "ethereum.svg";
                  qrCoin.src = `https://quickchart.io/qr?text=${ethereum}`;
                }
                if (depositMethod === 'Bitcoin') {
                  // refUrl.textContent = bitcoin;
                  // refUrl.innerHTML = bitcoin;
                  wallet.value = bitcoin;
                  coinImg.src = "bitcoin.svg";
                  qrCoin.src = `https://quickchart.io/qr?text=${bitcoin}`;
                }
                if (depositMethod === 'Tether') {
                  // refUrl.textContent = tether;
                  // refUrl.innerHTML = tether;
                  wallet.value = tether;
                  coinImg.src = "tether-usdt-logo.svg";
                  qrCoin.src = `https://quickchart.io/qr?text=${tether}`;
                }

                coins = depositMethod;
                async function getCryptoData(cryptoSymbol) {
                  try {
                    const response = await fetch(
                      `https://api.coingecko.com/api/v3/coins/${cryptoSymbol}`,
                    );
                    const data = await response.json();
                    return data;
                  } catch (error) {
                    console.error('Error fetch3ing cryptocurrency data:', error);
                  }
                }
                // Example usage
                const cryptoSymbol = coins.toLowerCase();
                const usdAmount = amount.value;
                getCryptoData(cryptoSymbol).then((data) => {
                  price = data.market_data.current_price.usd;
                  symbol = data.name;
                  bitcoinFraction = usdAmount / price;
                  depAmt.forEach(e => {
                    e.textContent = ` ${currency}${usdAmount}`;
                  })


                  note.textContent = `Please ensure your payment was made to this ${cryptoSymbol} Wallet ${wallet.value}`;
                  coinVal.textContent = `with a value of ${bitcoinFraction.toFixed(4)} ${data.symbol.toUpperCase()} `;
                  const sessionGetUserID = localStorage.getItem('uId');
                  const requestData = {
                    cryptovalue: bitcoinFraction,
                    cryptoAmt: usdAmount,
                    netWork: symbol,
                    sessionGetUserID: sessionGetUserID,
                    companyWallet: wallet.value,
                  };
                  axios
                    .post('../newApi/api/task/depositPage', requestData)
                    .then((response) => {
                      if (response.status === 201) {
                        const readResult = response.data.message;
                        depositId = readResult.userId;
                        if (readResult.message === 'true') {
                          // Toasty.showToast(
                          //   'success',
                          //   `your deposit has been recorded you are to pay ${usdAmount} ${currency} in value ${bitcoinFraction.toFixed(2)} ${symbol.toUpperCase()}`,
                          // );
                          unSetLoader(button, 'Fund Now');
                          firstFund.style.display = 'none';
                          loaderOverlay.style.display = 'flex';
                          setTimeout(() => {
                            loaderOverlay.style.display = 'none';
                          }, 6000);
                          seconfDetail.style.visibility = 'visible';
                        }
                      }
                    })
                    .catch((error) => {
                      if (error.response && error.response.status === 422) {
                        const message = error.response.data.errors[0];
                        Toasty.showToast('danger', message);
                      }
                    })
                });
              }
            })
            .catch((error) => {
              if (error.response && error.response.status === 422) {
                const message = error.response.data.errors[0];
                Toasty.showToast('danger', message);
              }
            }).finally(function () {
              unSetLoader(button, 'Fund Now');
            })
        });
      }, 3000);
    } catch (error) {
      console.log(error);

    }
  }





  Send.addEventListener('click', function (e) {
    e.preventDefault();
    seconfDetail.style.display = 'none';
    thirdDetail.style.visibility = 'visible';

  });

});
