document.addEventListener('DOMContentLoaded', function () {
  const header = document.querySelector('#header');

  const setHeaderHtml = function () {
    const html = ` 
          <div class="nk-sidebar-element nk-sidebar-head">
            <center>
              <div class="nk-sidebar-brand">
                <a
                  href="index"
                  class="logo-link nk-sidebar-logo"
                  style="border-radius: 5px; padding: 5px"
                >

          <img style="height: 55px;width: 110px;"
            class="logo-light logo-img"
            src="../assets/1.png"
            srcset="../assets/1.png 2x"
            alt="logo"
          />
          <img style="height: 55px;width: 110px;"
            class="logo-dark logo-img"
            src="../assets/1.png"
            srcset="../assets/1.png 2x"
            alt="logo-dark"
          />
                </a>
              </div>
            </center>
            <div class="nk-menu-trigger me-n2">
              <a
                href="#"
                class="nk-nav-toggle nk-quick-nav-icon d-xl-none"
                data-target="sidebarMenu"
              >
                <em class="icon ni ni-arrow-left"></em>
              </a>
            </div>
          </div>
          <div class="nk-sidebar-element">
            <div class="nk-sidebar-body" data-simplebar>
              <div class="nk-sidebar-content">
                <div class="nk-sidebar-widget d-none d-xl-block">
                  <div class="user-account-info between-center">
                    <div class="user-account-main">
                      <h6 class="overline-title-alt" style="color: #ccfff2">
                        Available Balance
                      </h6>
                      <div
                        class="user-balance"
                        style="color: #fff; font-weight: bolder" id="userBalance"
                      >
                        
                      </div>
                    </div>
                    <a href="#" class="btn btn-white btn-icon btn-light">
                      <em class="icon ni ni-line-chart"></em>
                    </a>
                  </div>
                  <ul class="user-account-data gy-1">
                    <li>
                      <div class="user-account-label">
                        <span class="sub-text">Profits (7d)</span>
                      </div>
                      <div class="user-account-value">
                        <span class="text-success ms-2" style="color: #fff" id="userProfi">
                           
                        </span>
                      </div>
                    </li>
                    <li>
                      <div class="user-account-label">
                        <span class="sub-text">Deposit So Far</span>
                      </div>
                      <div class="user-account-value">
                        <span class="sub-text" id="amountDeposit">
                          
                        </span>
                      </div>
                    </li>
                  </ul>
                  <div class="user-account-actions">
                    <ul class="g-3">
                      <li>
                        <a
                          href="deposit"
                          class="btn btn-lg btn-primary"
                          style="
                            background-color: #39ac73;
                            border: 1px solid #39ac73;
                          "
                        >
                          <span>Deposit</span>
                        </a>
                      </li>
                      <li>
                        <a
                          href="withdraw"
                          class="btn btn-lg btn-warning"
                          style="
                            background-color: #39ac73;
                            border: 1px solid #39ac73;
                          "
                        >
                          <span>Withdraw</span>
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>
                <div
                  class="nk-sidebar-widget nk-sidebar-widget-full d-xl-none pt-0"
                >
                  <a
                    class="nk-profile-toggle toggle-expand"
                    data-target="sidebarProfile"
                    href="#"
                  >
                    <div class="user-card-wrap">
                      <div class="user-card">
                        <div
                          class="user-avatar"
                          style="background-color: #39ac73"
                        >
                          <span id="abbrName"></span>
                        </div>
                        <div class="user-info">
                          <span class="lead-text"  id="username"></span>
                          <span class="sub-text" id="userEmail"></span>
                        </div>
                        <div class="user-action">
                          <em class="icon ni ni-chevron-down"></em>
                        </div>
                      </div>
                    </div>
                  </a>
                  <div
                    class="nk-profile-content toggle-expand-content"
                    data-content="sidebarProfile"
                  >
                    <div class="user-account-info between-center">
                      <div class="user-account-main">
                        <h6 class="overline-title-alt">Available Balance</h6>
                        <div class="user-balance" style="color: #00bf76" id="userBalance">
                         
                        </div>
                      </div>
                      <a href="#" class="btn btn-icon btn-light">
                        <em class="icon ni ni-line-chart"></em>
                      </a>
                    </div>
                    <ul class="user-account-data">
                      <li>
                        <div class="user-account-label">
                          <span class="sub-text">Profits</span>
                        </div>
                        <div class="user-account-value">
                          <span class="lead-text" style="color: #00bf76" id="userProfi">
                        
                       
                          </span>
                        </div>
                      </li>
                      <li>
                        <div class="user-account-label">
                          <span class="sub-text">Deposit So Far</span>
                        </div>
                        <div class="user-account-value">
                          <span class="sub-text text-base" id="amountDeposit"></span>
                        </div>
                      </li>
                    </ul>
                    <ul class="user-account-links">
                      <li>
                        <a
                          href="withdraw"
                          class="link"
                          style="color: white"
                        >
                          <span>Withdraw Funds</span>
                          <em class="icon ni ni-wallet-out"></em>
                        </a>
                      </li>
                      <li>
                        <a href="deposit" class="link" style="color: white">
                          <span>Deposit Funds</span>
                          <em class="icon ni ni-wallet-in"></em>
                        </a>
                      </li>
                    </ul>
                    <ul class="link-list">
                      <li>
                        <a href="account">
                          <em class="icon ni ni-user-alt"></em>
                          <span>View Profile</span>
                        </a>
                      </li>
                      <li>
                        <a href="account">
                          <em class="icon ni ni-setting-alt"></em>
                          <span>Account Setting</span>
                        </a>
                      </li>
                    </ul>
                    <ul class="link-list">
                      <li>
                        <a  id="logout" style="color: #ff4d4d">
                          <em
                            class="icon ni ni-signout"
                            style="color: #ff4d4d"
                          ></em>
                          <span>Sign out</span>
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>
                <div class="nk-sidebar-menu">
                  <ul class="nk-menu">
                    <li class="nk-menu-heading">
                      <h6 class="overline-title">Menu</h6>
                    </li>
                    <li class="nk-menu-item">
                      <a
                        href="index"
                        class="nk-menu-link"
                        style="color: white"
                      >
                        <span class="nk-menu-icon" style="color: white">
                          <em class="icon ni ni-dashboard"></em>
                        </span>
                        <span class="nk-menu-text" style="color: white">
                          My Dashboard
                        </span>
                      </a>
                    </li>

                    <li class="nk-menu-item">
                      <a
                        href="account"
                        class="nk-menu-link"
                        style="color: white"
                      >
                        <span class="nk-menu-icon" style="color: white">
                          <em class="icon ni ni-user-c"></em>
                        </span>
                        <span class="nk-menu-text" style="color: white">
                          Account Profile
                        </span>
                      </a>
                    </li>

                    <li class="nk-menu-item">
                      <a
                        href="deposit"
                        class="nk-menu-link"
                        style="color: white"
                      >
                        <span class="nk-menu-icon" style="color: white">
                          <em class="icon ni ni-wallet-alt"></em>
                        </span>
                        <span class="nk-menu-text" style="color: white">
                          Deposit
                        </span>
                      </a>
                    </li>

                    <li class="nk-menu-item">
                      <a
                        href="live-trading"
                        class="nk-menu-link"
                        style="color: white"
                      >
                        <span class="nk-menu-icon" style="color: white">
                          <em class="icon ni ni-list-index"></em>
                        </span>
                        <span class="nk-menu-text" style="color: white">
                          Live Trading
                        </span>
                      </a>
                    </li>

                    <li class="nk-menu-item">
                      <a
                        href="copy-traders"
                        class="nk-menu-link"
                        style="color: white"
                      >
                        <span class="nk-menu-icon" style="color: white">
                          <em class="icon ni ni-copy"></em>
                        </span>
                        <span class="nk-menu-text" style="color: white">
                          Copy Trade Experts
                        </span>
                      </a>
                    </li>

                    <li class="nk-menu-item">
                      <a
                        href="swap"
                        class="nk-menu-link"
                        style="color: white"
                      >
                        <span class="nk-menu-icon" style="color: white">
                          <em class="icon ni ni-copy"></em>
                        </span>
                        <span class="nk-menu-text" style="color: white">
                          Swap Crypto
                        </span>
                      </a>
                    </li>

                    <li class="nk-menu-item">
                      <a
                        href="tradehistory"
                        class="nk-menu-link"
                        style="color: white"
                      >
                        <span class="nk-menu-icon" style="color: white">
                          <em class="icon ni ni-dashlite"></em>
                        </span>
                        <span class="nk-menu-text" style="color: white">
                          Trade History
                        </span>
                      </a>
                    </li>
                    <li class="nk-menu-item">
                      <a
                        href="Profithistory"
                        class="nk-menu-link"
                        style="color: white"
                      >
                        <span class="nk-menu-icon" style="color: white">
                          <em class="icon ni ni-dashlite"></em>
                        </span>
                        <span class="nk-menu-text" style="color: white">
                          Earned History
                        </span>
                      </a>
                    </li>

                    <li class="nk-menu-item">
                      <a
                        href="plans"
                        class="nk-menu-link"
                        style="color: white"
                      >
                        <span class="nk-menu-icon" style="color: white">
                          <em class="icon ni ni-layers"></em>
                        </span>
                        <span class="nk-menu-text" style="color: white">
                          Investment Plans
                        </span>
                      </a>
                    </li>

                    <li class="nk-menu-item">
                      <a
                        href="planhistory"
                        class="nk-menu-link"
                        style="color: white"
                      >
                        <span class="nk-menu-icon" style="color: white">
                          <em class="icon ni ni-wallet-alt"></em>
                        </span>
                        <span class="nk-menu-text" style="color: white">
                         plan History
                        </span>
                      </a>
                    </li>
                    <li class="nk-menu-item">
                      <a
                        href="deposithistory"
                        class="nk-menu-link"
                        style="color: white"
                      >
                        <span class="nk-menu-icon" style="color: white">
                          <em class="icon ni ni-wallet-alt"></em>
                        </span>
                        <span class="nk-menu-text" style="color: white">
                          Deposit History
                        </span>
                      </a>
                    </li>

                    <li class="nk-menu-item">
                      <a
                        href="withdraw"
                        class="nk-menu-link"
                        style="color: white"
                      >
                        <span class="nk-menu-icon" style="color: white">
                          <em class="icon ni ni-wallet-alt"></em>
                        </span>
                        <span class="nk-menu-text" style="color: white">
                          Withdrawals
                        </span>
                      </a>
                    </li>

                    <li class="nk-menu-item">
                      <a
                        href="support"
                        class="nk-menu-link"
                        style="color: white"
                      >
                        <span class="nk-menu-icon" style="color: white">
                          <em class="icon ni ni-chat-circle"></em>
                        </span>
                        <span class="nk-menu-text" style="color: white">
                          Our Support
                        </span>
                      </a>
                    </li>

                    <!--       
                                 <li class="nk-menu-item"><a href="setup-con"
                                            class="nk-menu-link" style='color:white'><span class="nk-menu-icon"><em
                                                    class="icon ni ni-account-setting" style='color:white'></em></span><span
                                                class="nk-menu-text"  style="color:white">Setup Wallet</span></a></li>
                                                -->

                    <li class="nk-menu-item">
                      <a
                        id="logout"
                        class="nk-menu-link"
                        style="color: #ff4d4d"
                      >
                        <span class="nk-menu-icon" style="color: #ff4d4d">
                          <em class="icon ni ni-signout"></em>
                        </span>
                        <span class="nk-menu-text">Log Out</span>
                      </a>
                    </li>
                  </ul>
                </div>

                <div class="nk-sidebar-footer">
                  <ul class="nk-menu nk-menu-footer">
                    <li class="nk-menu-item">
                      <a href="#" class="nk-menu-link">
                        <span class="nk-menu-icon">
                          <em class="icon ni ni-help-alt"></em>
                        </span>
                        <span class="nk-menu-text">Support</span>
                      </a>
                    </li>
                    <li class="nk-menu-item ms-auto">
                      <div class="dropup">
                        <a
                          href
                          class="nk-menu-link dropdown-indicator has-indicator"
                          data-bs-toggle="dropdown"
                          data-offset="0,10"
                        >
                          <span class="nk-menu-icon">
                            <em class="icon ni ni-globe"></em>
                          </span>
                          <span class="nk-menu-text">English</span>
                        </a>
                        <div
                          class="dropdown-menu dropdown-menu-sm dropdown-menu-end"
                        >
                          <ul class="language-list">
                            <li>
                              <a href="#" class="language-item">
                                <img
                                  src="images/english.png"
                                  alt
                                  class="language-flag"
                                />
                                <span class="language-name">English</span>
                              </a>
                            </li>
                            <li>
                              <a href="#" class="language-item">
                                <img
                                  src="images/spanish.png"
                                  alt
                                  class="language-flag"
                                />
                                <span class="language-name">Español</span>
                              </a>
                            </li>
                            <li>
                              <a href="#" class="language-item">
                                <img
                                  src="images/french.png"
                                  alt
                                  class="language-flag"
                                />
                                <span class="language-name">Français</span>
                              </a>
                            </li>
                            <li>
                              <a href="#" class="language-item">
                                <img
                                  src="images/turkey.png"
                                  alt
                                  class="language-flag"
                                />
                                <span class="language-name">Türkçe</span>
                              </a>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>`;
    header.insertAdjacentHTML('beforeend', html);
  };
  setHeaderHtml();
});
