document.addEventListener('DOMContentLoaded', function () {
 const myModalElement = document.getElementById('accountUpdatePlanModal');
 const myModal = new bootstrap.Modal(myModalElement);
 myModal.show();
});
