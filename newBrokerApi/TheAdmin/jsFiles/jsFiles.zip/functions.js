function fetchUserDetailsWithAxios() {
  const userId = localStorage.getItem('uId')
    ? localStorage.getItem('uId')
    : null;
  return axios.get(
    `../newApi/api/task/fetchUserDetails/${userId}`,
  );
}
function fetchUserDetailsAndTransactionInfosWithAxios() {
  const userId = localStorage.getItem('uId')
    ? localStorage.getItem('uId')
    : null;
  return axios.get(
    `../newApi/api/task/fetchUserDetailsWithTransInfo/${userId}`,
  );
}
