document.addEventListener('DOMContentLoaded', function () {
  const userId = localStorage.getItem('uId');
  const form = document.getElementById('form');
  const submitBtn = form.querySelector('button');
  console.log(submitBtn);

  form.addEventListener('submit', function (e) {
    e.preventDefault();
 
 
      const userDet = new FormData(this);
      userDet.append('userid', userId);
      axios
        .post('../newApi/api/task/updateuserDetails', userDet)
        .then((response) => {
          if (response.status === 201) {
            const readResult = response.data.message;
            Toasty.showToast('success', readResult);
            setTimeout(() => {
              // location.href = 'user-profile-my-profile';
            }, 5000);
          }
        })
        .catch((error) => {
          if (error.response && error.response.status === 422) {
            const message = error.response.data.errors[0];
            // Toasty.showToast('danger', message);
          }
        }) 
   
  });


});

