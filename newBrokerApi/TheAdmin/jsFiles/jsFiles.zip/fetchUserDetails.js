document.addEventListener('DOMContentLoaded', function () {
  const fetchUser = fetchUserDetailsWithAxios();
  const userName = document.querySelectorAll('#username') ?? null;
  const abbrName = document.querySelectorAll('#abbrName') ?? null;
  const userEmail = document.querySelectorAll('#userEmail') ?? null;
  const location = document.querySelector('#location') ?? null;
  const dateJoined = document.getElementById('dateJoined') ?? null;
  const userlink = document.querySelector('#userlink') ?? null;
  const userrPlan = document.getElementById('userPlan') ?? null;
  const userBalanc = document.querySelectorAll('#userBalance') ?? null;
  const userProfi = document.querySelectorAll('#userProfi') ?? null;
  const copyLink = document.querySelectorAll('#copyLink') ?? null;
  const amountDeposit = document.querySelectorAll('#amountDeposit') ?? null;
  const anotheruserName = document.querySelector('.anotheruserName') ?? null;
  const alertMEss = document.querySelector('#alertMEss') ?? null;
  const twofactor = document.querySelector('#twofactor') ?? null;
  const message = document.querySelector('#message') ?? null;
  const messagenum = document.querySelector('#messagenumbbb') ?? null;
  const stock = document.querySelector('#stock') ?? null;
  const el = document.querySelector('#el') ?? null;
  // const currencySign = document.querySelector('#currencySign') ?? null;
  const userid = localStorage.getItem('uId');
  let sig = '';

  fetchUser
    .then((response) => {
      if (response.status === 201) {
        const readResult = JSON.parse(response.data.message);
        const {
          id,
          fullName,
          email,
          phoneNumber,
          country,
          state,
          currency,
          occupation,
          password,
          referer,
          encryptedPassword,
          dateOc,
          userId,
          UserLogin,
          AllowLogin,
          emailVerication,
          userBalance,
          userProfit,
          amountDeposited,
          amountWithdrawal,
          UserStatus,
          ipAdress,
          userPlan,
          referralBonus,
          AccountManager,
          TradingPercentage,
          Message,
          allowMessage,
          sitelink,
          Bitcoin,
          Etheruem,
          USDT,
          BitcoinCash,
          Doge,
          RIPPLE,
        } = readResult;

        if (el !== null) {

          const html = ` 
              <div class="nk-block-head">
                    <div class="nk-block-head-sub"><span>Welcome!</span></div>
                    <div class="nk-block-between-md g-4">
                      <div class="nk-block-head-content">
                        <h2 class="nk-block-title fw-normal">${fullName}</h2>
                      </div>
                      <div class="nk-block-head-content">
                        <ul class="nk-block-tools gx-3">
                          <li>
                            <a href="deposit" class="btn btn-primary">
                              <span>Deposit</span>
                              <em class="icon ni ni-wallet-alt"></em>
                            </a>
                          </li>
  
                          <li>
                            <a href="copy-traders" class="btn btn-primary">
                              <span>Copy Expert's</span>
                              <em class="icon ni ni-user-alt"></em>
                            </a>
                          </li>
                        </ul>
                      </div>
  
                      <li>
                        <a
                          href="tradehistory"
                          class="btn btn-primary"
                          style="
                            text-align: center;
                            background-color: #00b386;
                            border: 2px solid #00b386;
                          "
                        >
                          <span style="text-align: center">
                            Trade History Recap's
                          </span>
                          <em class="icon ni ni-file-doc"></em>
                        </a>
                      </li>
                    </div>
                  </div>
  
                  <div class="nk-block">
                    <div class="row gy-gs">
                      <div class="col-lg-5 col-xl-4">
                        <div class="nk-block">
                          <div class="nk-block-head-xs">
                            <div class="nk-block-head-content">
                              <h5 class="nk-block-title title">Overview</h5>
                            </div>
                          </div>
                          <div class="nk-block">
                            <div
                              class="card-bordered text-light is-dark h-100"
                              style="
                                background-color: rgba(28, 16, 86, 0.5);
                                border-radius: 5px;
                              "
                            >
                              <div class="card-inner">
                                <div class="nk-wg7">
                                  <div class="nk-wg7-stats">
                                    <h2
                                      class="n"
                                      style="
                                        color: #fff;
                                        font-weight: bolder;
                                        font-size: 22px;
                                      "
                                    >
                                      BALANCE
                                    </h2>
                                    <div
                                      class=""
                                      style="color: #fff; font-size: 17px"
                                    >
                                      ${currency}${formatNumberWithCommasAndDecimal(Number(userBalance))}
                                    </div>
                                  </div>
                                  <div class="nk-wg7-stats-group">
                                    <div class="nk-wg7-stats w-50">
                                      <div
                                        class="nk-wg7-ti"
                                        style="
                                          color: #fff;
                                          font-weight: bolder;
                                          font-size: 17px;
                                        "
                                      >
                                        DEPOSIT
                                      </div>
                                      <div
                                        class=""
                                        style="color: #fff; font-size: 17px"
                                      >
                                        ${currency}${formatNumberWithCommasAndDecimal(Number(amountDeposited))}
                                      </div>
                                    </div>
  
                                    <div class="nk-wg7-stats w-50">
                                      <div
                                        class="nk-wg7-tite"
                                        style="
                                          color: #fff;
                                          font-weight: bolder;
                                          font-size: 17px;
                                        "
                                      >
                                        PROFIT
                                      </div>
                                      <div
                                        class=""
                                        style="color: #fff; font-size: 17px"
                                      >
                                        ${currency}${formatNumberWithCommasAndDecimal(Number(userProfit))}
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
  
                      <div
                        class="col-sm-12 col-lg-12 col-xl-12 col-xxl-12"
                        style="padding: 10px"
                      ></div>
  
                      <div class="col-sm-12 col-lg-12 col-xl-12 col-xxl-12">
                        <div
                          class="card-bordered"
                          style="background-color: #f83f3f; border-radius: 10px"
                        >
                          <div class="nk-wgw">
                            <div class="nk-wgw-inner">
                              <a class="nk-wgw-name" href="#">
                                <div
                                  class="nk-wgw-icon is-default"
                                  style="
                                    background-color: white;
                                    padding: 10px;
                                    width: 55px;
                                    height: 55px;
                                  "
                                >
                                  <img
                                    src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/bb/Tesla_T_symbol.svg/1200px-Tesla_T_symbol.svg.png"
                                  />
                                </div>
                                <h5
                                  class="nk-wgw-title title"
                                  style="color: white"
                                >
                                  Tesla Stock
                                </h5>
                              </a>
                              <div class="nk-wgw-balance">
                                <div class="amount" style="color: white">
                                  ${currency}${formatNumberWithCommasAndDecimal(Number(userBalance))}
                                  <b
                                    class="currency currency-nio"
                                    style="color: white"
                                  >
                                    TESLA
                                  </b>
                                </div>
                                <div class="amount-sm" style="color: white">
                                  ${currency}${formatNumberWithCommasAndDecimal(Number(userBalance))}
                                  <span class="currency currency-usd">USD</span>
                                </div>
                              </div>
                            </div>
  
                            <div class="nk-wgw-actions">
                              <ul>
                                <li class="col-sm-12" style="margin-bottom: 10px">
                                  <a
                                    href="deposit"
                                    style="
                                      background-color: #1a1a1a;
                                      padding: 10px;
                                      color: #262626;
                                      border-radius: 10px;
                                    "
                                  >
                                    <em
                                      class="icon ni ni-arrow-down-left"
                                      style="font-weight: bolder; color: #fff"
                                    ></em>
                                    <span style="color: #fff">
                                      Deposit Via Any Crypto Method
                                    </span>
                                  </a>
                                </li>
  
                                <li>
                                  <a
                                    href="withdraw"
                                    style="
                                      background-color: #1a1a1a;
                                      padding: 10px;
                                      color: #262626;
                                      border-radius: 10px;
                                    "
                                  >
                                    <em
                                      class="icon ni ni-arrow-to-right"
                                      style="font-weight: bolder; color: #fff"
                                    ></em>
                                    <span style="color: #fff">Withdraw</span>
                                  </a>
                                </li>
                              </ul>
                            </div>
                            <div class="nk-wgw-more dropdown">
                              <a
                                href="#"
                                class="btn btn-icon btn-trigger"
                                data-bs-toggle="dropdown"
                              >
                                <em class="icon ni ni-more-h"></em>
                              </a>
  
                              <a
                                href="#"
                                style="
                                  padding: 10px;
                                  background-color: white;
                                  color: #f83f3f;
                                  font-weight: bold;
                                  border-radius: 100%;
                                "
                              >
                                New
                              </a>
  
                              <div
                                class="dropdown-menu dropdown-menu-xs dropdown-menu-end"
                              >
                                <ul class="link-list-plain sm">
                                  <li><a href="deposit">Deposit</a></li>
                                  <li><a href="withdraw">Withdraw</a></li>
                                </ul>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
  
                      <div class="nk-block" style="margin-top: 40px">
                        <div class="nk-block-head-sm">
                          <div class="nk-block-head-content">
                            <h5 class="nk-block-title title">Crypto Accounts</h5>
                          </div>
                        </div>
                        <div class="row g-gs">
                          <div class="col-sm-6 col-lg-4 col-xl-6 col-xxl-4">
                            <div
                              class="card-bordered is-dark"
                              style="border-radius: 10px"
                            >
                              <div class="nk-wgw">
                                <div class="nk-wgw-inner">
                                  <a class="nk-wgw-name" href="#">
                                    <div class="nk-wgw-icon is-default">
                                      <img
                                        src="img/bitcoin.png"
                                        style="
                                          border: 2px solid #fff;
                                          border-radius: 100%;
                                        "
                                      />
                                    </div>
                                    <h5
                                      class="nk-wgw-title title"
                                      style="color: white"
                                    >
                                      Bitcoin
                                    </h5>
                                  </a>
                                  <div class="nk-wgw-balance">
                                    <div class="amount" style="color: white">
                                      
                                 <b class="currency currency-nio" style="color: white"
                                      >
                                      ${currency}${formatNumberWithCommasAndDecimal(Number(Bitcoin))}
                                      </b>
                                    </div>
                                           <div class="amount-sm" style="color: white">
                                      <span class="currency currency-usd">
                                        BTC
                                      </span>
                                    </div>
                                  </div>
                                </div>
  
                                <div class="nk-wgw-actions">
                                  <ul>
                                    <li>
                                      <a href="deposit">
                                        <em
                                          class="icon ni ni-arrow-down-left"
                                        ></em>
                                        <span>Deposit</span>
                                      </a>
                                    </li>
                                    <li>
                                      <a href="withdraw">
                                        <em
                                          class="icon ni ni-arrow-to-right"
                                        ></em>
                                        <span>Withdraw</span>
                                      </a>
                                    </li>
                                    <li>
                                      <a href="swap">
                                        <em class="icon ni ni-swap"></em>
                                        <span>Swap</span>
                                      </a>
                                    </li>
                                  </ul>
                                </div>
                                <div class="nk-wgw-more dropdown">
                                  <a
                                    href="#"
                                    class="btn btn-icon btn-trigger"
                                    data-bs-toggle="dropdown"
                                  >
                                    <em class="icon ni ni-more-h"></em>
                                  </a>
                                  <div
                                    class="dropdown-menu dropdown-menu-xs dropdown-menu-end"
                                  >
                                    <ul class="link-list-plain sm">
                                      <li><a href="deposit">Deposit</a></li>
                                      <li><a href="withdraw">Withdraw</a></li>
                                      <li><a href="swap">Swap</a></li>
                                    </ul>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
  
                          <div class="col-sm-6 col-lg-4 col-xl-6 col-xxl-4">
                            <div
                              class="card-bordered is-dark"
                              style="border-radius: 10px"
                            >
                              <div class="nk-wgw">
                                <div class="nk-wgw-inner">
                                  <a class="nk-wgw-name" href="#">
                                    <div class="nk-wgw-icon is-default">
                                      <img
                                        src="img/ethereum.png"
                                        style="
                                          border: 2px solid #fff;
                                          border-radius: 100%;
                                        "
                                      />
                                    </div>
                                    <h5
                                      class="nk-wgw-title title"
                                      style="color: white"
                                    >
                                      Ethereum
                                    </h5>
                                  </a>
                                  <div class="nk-wgw-balance">
                                    <div class="amount" style="color: white">
                                      ${currency}${formatNumberWithCommasAndDecimal(Number(Etheruem))}
                                      <b
                                        class="currency currency-nio"
                                        style="color: white"
                                      ></b>
                                    </div>
                                    <div class="amount-sm" style="color: white">
                                      <span class="currency currency-usd">
                                        ETH
                                      </span>
                                    </div>
                                  </div>
                                </div>
  
                                <div class="nk-wgw-actions">
                                  <ul>
                                    <li>
                                      <a href="deposit">
                                        <em
                                          class="icon ni ni-arrow-down-left"
                                        ></em>
                                        <span>Deposit</span>
                                      </a>
                                    </li>
                                    <li>
                                      <a href="withdraw">
                                        <em
                                          class="icon ni ni-arrow-to-right"
                                        ></em>
                                        <span>Withdraw</span>
                                      </a>
                                    </li>
                                    <li>
                                      <a href="swap">
                                        <em class="icon ni ni-swap"></em>
                                        <span>Swap</span>
                                      </a>
                                    </li>
                                  </ul>
                                </div>
                                <div class="nk-wgw-more dropdown">
                                  <a
                                    href="#"
                                    class="btn btn-icon btn-trigger"
                                    data-bs-toggle="dropdown"
                                  >
                                    <em class="icon ni ni-more-h"></em>
                                  </a>
                                  <div
                                    class="dropdown-menu dropdown-menu-xs dropdown-menu-end"
                                  >
                                    <ul class="link-list-plain sm">
                                      <li><a href="deposit">Deposit</a></li>
                                      <li><a href="withdraw">Withdraw</a></li>
                                      <li><a href="swap">Swap</a></li>
                                    </ul>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
  
                          <div class="col-sm-6 col-lg-4 col-xl-6 col-xxl-4">
                            <div
                              class="card-bordered is-dark"
                              style="border-radius: 10px"
                            >
                              <div class="nk-wgw">
                                <div class="nk-wgw-inner">
                                  <a class="nk-wgw-name" href="#">
                                    <div class="nk-wgw-icon is-default">
                                      <img
                                        src="img/tether.png"
                                        style="
                                          border: 4px solid #fff;
                                          border-radius: 100%;
                                        "
                                      />
                                    </div>
                                    <h5
                                      class="nk-wgw-title title"
                                      style="color: white"
                                    >
                                      USDT
                                    </h5>
                                  </a>
                                  <div class="nk-wgw-balance">
                                    <div class="amount" style="color: white">
                                      ${currency}${formatNumberWithCommasAndDecimal(Number(USDT))}
                                      <b
                                        class="currency currency-nio"
                                        style="color: white"
                                      ></b>
                                    </div>
                                    <div class="amount-sm" style="color: white">
                                      <span class="currency currency-usd">
                                        USDT
                                      </span>
                                    </div>
                                  </div>
                                </div>
  
                                <div class="nk-wgw-actions">
                                  <ul>
                                    <li>
                                      <a href="deposit">
                                        <em
                                          class="icon ni ni-arrow-down-left"
                                        ></em>
                                        <span>Deposit</span>
                                      </a>
                                    </li>
                                    <li>
                                      <a href="withdraw">
                                        <em
                                          class="icon ni ni-arrow-to-right"
                                        ></em>
                                        <span>Withdraw</span>
                                      </a>
                                    </li>
                                    <li>
                                      <a href="swap">
                                        <em class="icon ni ni-swap"></em>
                                        <span>Swap</span>
                                      </a>
                                    </li>
                                  </ul>
                                </div>
                                <div class="nk-wgw-more dropdown">
                                  <a
                                    href="#"
                                    class="btn btn-icon btn-trigger"
                                    data-bs-toggle="dropdown"
                                  >
                                    <em class="icon ni ni-more-h"></em>
                                  </a>
                                  <div
                                    class="dropdown-menu dropdown-menu-xs dropdown-menu-end"
                                  >
                                    <ul class="link-list-plain sm">
                                      <li><a href="deposit">Deposit</a></li>
                                      <li><a href="withdraw">Withdraw</a></li>
                                      <li><a href="swap">Swap</a></li>
                                    </ul>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
  
                          <div class="col-sm-6 col-lg-4 col-xl-6 col-xxl-4">
                            <div
                              class="card-bordered is-dark"
                              style="border-radius: 10px"
                            >
                              <div class="nk-wgw">
                                <div class="nk-wgw-inner">
                                  <a class="nk-wgw-name" href="#">
                                    <div class="nk-wgw-icon is-default">
                                      <img
                                        src="img/bitcoincash.png"
                                        style="
                                          border: 4px solid #fff;
                                          border-radius: 100%;
                                        "
                                      />
                                    </div>
                                    <h5
                                      class="nk-wgw-title title"
                                      style="color: white"
                                    >
                                      Bitcoin Cash
                                    </h5>
                                  </a>
                                  <div class="nk-wgw-balance">
                                    <div class="amount" style="color: white">
                                      ${currency}${formatNumberWithCommasAndDecimal(Number(BitcoinCash))}
                                      <b
                                        class="currency currency-nio"
                                        style="color: white"
                                      ></b>
                                    </div>
                                    <div class="amount-sm" style="color: white">
                                      <span class="currency currency-usd">
                                        BCH
                                      </span>
                                    </div>
                                  </div>
                                </div>
  
                                <div class="nk-wgw-actions">
                                  <ul>
                                    <li>
                                      <a href="deposit">
                                        <em
                                          class="icon ni ni-arrow-down-left"
                                        ></em>
                                        <span>Deposit</span>
                                      </a>
                                    </li>
                                    <li>
                                      <a href="withdraw">
                                        <em
                                          class="icon ni ni-arrow-to-right"
                                        ></em>
                                        <span>Withdraw</span>
                                      </a>
                                    </li>
                                    <li>
                                      <a href="swap">
                                        <em class="icon ni ni-swap"></em>
                                        <span>Swap</span>
                                      </a>
                                    </li>
                                  </ul>
                                </div>
                                <div class="nk-wgw-more dropdown">
                                  <a
                                    href="#"
                                    class="btn btn-icon btn-trigger"
                                    data-bs-toggle="dropdown"
                                  >
                                    <em class="icon ni ni-more-h"></em>
                                  </a>
                                  <div
                                    class="dropdown-menu dropdown-menu-xs dropdown-menu-end"
                                  >
                                    <ul class="link-list-plain sm">
                                      <li><a href="deposit">Deposit</a></li>
                                      <li><a href="withdraw">Withdraw</a></li>
                                      <li><a href="swap">Swap</a></li>
                                    </ul>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
  
                          <div class="col-sm-6 col-lg-4 col-xl-6 col-xxl-4">
                            <div
                              class="card-bordered is-dark"
                              style="border-radius: 10px"
                            >
                              <div class="nk-wgw">
                                <div class="nk-wgw-inner">
                                  <a class="nk-wgw-name" href="#">
                                    <div class="nk-wgw-icon is-default">
                                      <img
                                        src="img/dogecoin.png"
                                        style="
                                          border: 4px solid #fff;
                                          border-radius: 100%;
                                        "
                                      />
                                    </div>
                                    <h5
                                      class="nk-wgw-title title"
                                      style="color: white"
                                    >
                                      Doge
                                    </h5>
                                  </a>
                                  <div class="nk-wgw-balance">
                                    <div class="amount" style="color: white">
                                      ${currency}${formatNumberWithCommasAndDecimal(Number(Doge))}
                                      <b
                                        class="currency currency-nio"
                                        style="color: white"
                                      ></b>
                                    </div>
                                    <div class="amount-sm" style="color: white">
                                      <span class="currency currency-usd">
                                        DOGE
                                      </span>
                                    </div>
                                  </div>
                                </div>
  
                                <div class="nk-wgw-actions">
                                  <ul>
                                    <li>
                                      <a href="deposit">
                                        <em
                                          class="icon ni ni-arrow-down-left"
                                        ></em>
                                        <span>Deposit</span>
                                      </a>
                                    </li>
                                    <li>
                                      <a href="withdraw">
                                        <em
                                          class="icon ni ni-arrow-to-right"
                                        ></em>
                                        <span>Withdraw</span>
                                      </a>
                                    </li>
                                    <li>
                                      <a href="swap">
                                        <em class="icon ni ni-swap"></em>
                                        <span>Swap</span>
                                      </a>
                                    </li>
                                  </ul>
                                </div>
                                <div class="nk-wgw-more dropdown">
                                  <a
                                    href="#"
                                    class="btn btn-icon btn-trigger"
                                    data-bs-toggle="dropdown"
                                  >
                                    <em class="icon ni ni-more-h"></em>
                                  </a>
                                  <div
                                    class="dropdown-menu dropdown-menu-xs dropdown-menu-end"
                                  >
                                    <ul class="link-list-plain sm">
                                      <li><a href="deposit">Deposit</a></li>
                                      <li><a href="withdraw">Withdraw</a></li>
                                      <li><a href="swap">Swap</a></li>
                                    </ul>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
  
                          <div class="col-sm-6 col-lg-4 col-xl-6 col-xxl-4">
                            <div
                              class="card-bordered is-dark"
                              style="border-radius: 10px"
                            >
                              <div class="nk-wgw">
                                <div class="nk-wgw-inner">
                                  <a class="nk-wgw-name" href="#">
                                    <div class="nk-wgw-icon is-default">
                                      <img
                                        src="img/xrp.png"
                                        style="
                                          border: 4px solid #fff;
                                          border-radius: 100%;
                                        "
                                      />
                                    </div>
                                    <h5
                                      class="nk-wgw-title title"
                                      style="color: white"
                                    >
                                      RIPPLE
                                    </h5>
                                  </a>
                                  <div class="nk-wgw-balance">
                                    <div class="amount" style="color: white">
                                      ${currency}${formatNumberWithCommasAndDecimal(Number(RIPPLE))}
                                      <b
                                        class="currency currency-nio"
                                        style="color: white"
                                      ></b>
                                    </div>
                                    <div class="amount-sm" style="color: white">
                                      <span class="currency currency-usd">
                                        XRP
                                      </span>
                                    </div>
                                  </div>
                                </div>
  
                                <div class="nk-wgw-actions">
                                  <ul>
                                    <li>
                                      <a href="deposit">
                                        <em
                                          class="icon ni ni-arrow-down-left"
                                        ></em>
                                        <span>Deposit</span>
                                      </a>
                                    </li>
                                    <li>
                                      <a href="withdraw">
                                        <em
                                          class="icon ni ni-arrow-to-right"
                                        ></em>
                                        <span>Withdraw</span>
                                      </a>
                                    </li>
                                    <li>
                                      <a href="swap">
                                        <em class="icon ni ni-swap"></em>
                                        <span>Swap</span>
                                      </a>
                                    </li>
                                  </ul>
                                </div>
                                <div class="nk-wgw-more dropdown">
                                  <a
                                    href="#"
                                    class="btn btn-icon btn-trigger"
                                    data-bs-toggle="dropdown"
                                  >
                                    <em class="icon ni ni-more-h"></em>
                                  </a>
                                  <div
                                    class="dropdown-menu dropdown-menu-xs dropdown-menu-end"
                                  >
                                    <ul class="link-list-plain sm">
                                      <li><a href="deposit">Deposit</a></li>
                                      <li><a href="withdraw">Withdraw</a></li>
                                      <li><a href="swap">Swap</a></li>
                                    </ul>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
  
                      <div class="col-lg-7 col-xl-8">
                        <div class="nk-block">
                          <div class="nk-block-head-xs">
                            <div class="nk-block-between-md g-2">
                              <div class="nk-block-head-content">
                                <h5 class="nk-block-title title">More Info</h5>
                              </div>
                            </div>
                          </div>
                          <div class="row g-2">
                            <div class="col-sm-4">
                              <div class="card bg-light">
                                <div class="nk-wgw sm">
                                  <a class="nk-wgw-inner" href="#">
                                    <div class="nk-wgw-name">
                                      <div class="nk-wgw-icon">
                                        <em class="icon ni ni-wallet-in"></em>
                                      </div>
                                      <h5 class="nk-wgw-title title">
                                        Referral Bonus
                                      </h5>
                                    </div>
                                    <div class="nk-wgw-balance">
                                        <div class="amount">${currency}${formatNumberWithCommasAndDecimal(Number(referralBonus))}</div>
                                    </div>
                                  </a>
                                </div>
                              </div>
                            </div>
                            <div class="col-sm-4">
                              <div class="card bg-light">
                                <div class="nk-wgw sm">
                                  <a class="nk-wgw-inner" href="#">
                                    <div class="nk-wgw-name">
                                      <div class="nk-wgw-icon">
                                        <em class="icon ni ni-wallet-out"></em>
                                      </div>
                                      <h5 class="nk-wgw-title title">
                                        Withdrawal
                                      </h5>
                                    </div>
                                    <div class="nk-wgw-balance">
                                        <div class="amount">${currency}${formatNumberWithCommasAndDecimal(Number(amountWithdrawal))}</div>
                                    </div>
                                  </a>
                                </div>
                              </div>
                            </div>
                            <div class="col-sm-4">
                              <div class="card bg-light">
                                <div class="nk-wgw sm">
                                  <a class="nk-wgw-inner" href="#">
                                    <div class="nk-wgw-name">
                                      <div class="nk-wgw-icon">
                                        <em class="icon ni ni-user"></em>
                                      </div>
                                      <h5 class="nk-wgw-title title">
                                        Account Manager
                                      </h5>
                                    </div>
                                    <div class="nk-wgw-balance">
                                      <div class="amount">${AccountManager}</div>
                                    </div>
                                  </a>
                                </div>
                              </div>
                            </div>
  
                            <div class="col-sm-4">
                              <div
                                class="card"
                                style="
                                  background-image: linear-gradient(
                                    green,
                                    #666666
                                  );
                                "
                              >
                                <div class="nk-wgw sm">
                                  <a class="nk-wgw-inner" href="#">
                                    <center>
                                      <div class="">
                                        <h5
                                          class="nk-wgw-title title"
                                          style="text-align: center; color: white"
                                        >
                                          Trading Percentage
                                        </h5>
                                      </div>
                                      <div class="nk-wgw-balance">
                                        <div class="amount" style="color: white">
                                          ${Number(TradingPercentage).toFixed(2)}%
                                          <em
                                            class="icon ni ni-arrow-long-up"
                                            style="
                                              border-radius: 100%;
                                              background-color: #00b383;
                                            "
                                          ></em>
                                        </div>
                                      </div>
                                    </center>
                                  </a>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
               `;
          el.insertAdjacentHTML('afterbegin', html);
        }


        if (UserStatus === 'Pending') {
          // window.location.href = 'userVerification';
        }

        if (UserLogin === 'disabled') {
          axios
            .post(`../newApi/api/task/logoutUser`)
            .then((response) => {
              if (response.status === 201) {
                const readResult = response.data.message;
                if (readResult === 'true') {
                  const getLInk = window.location.href;
                  localStorage.setItem('url', getLInk);
                  window.location.href = 'signin';
                }
              }
            })
            .catch((error) => {
              if (error.response && error.response.status === 422) {
                const message = error.response.data.errors[0];
                Toasty.showToast('danger', message);
              }
            });
        }
        // if (AlertMessage === 'enabled') {
        //   $('#statusSuccessModal').modal('show');
        //   SignalMessage === null
        //     ? (sig = `You Are Required To Subscribe To An Active User Plan`)
        //     : (sig = SignalMessage);
        //   alertMEss.innerHTML = sig;
        // }
        if (userrPlan !== null) {
          userrPlan.innerHTML = `${userPlan === '' || userPlan === 'none' ? 'none' : userPlan}`;
        }
        if (location !== null) {
          location.innerHTML = `${country} ${state}`;
        }
        if (dateJoined !== null) {
          dateJoined.innerHTML = convertDateFormat(dateoc); // Assuming convertDateFormat function exists
        }

        if (userBalanc !== null) {
          userBalanc.forEach((e) =>
            e.insertAdjacentHTML('afterbegin', `${currency}${formatNumberWithCommasAndDecimal(Number(userBalance))}`),
          );
        }
        if (userProfi !== null) {
          userProfi.forEach((e) =>
            e.insertAdjacentHTML('afterbegin', `${currency}${formatNumberWithCommasAndDecimal(Number(userProfit))} <em class="icon ni ni-arrow-long-up"></em>`),
          );
        }

        // if (currencySign !== null) {

        //   currencySign.insertAdjacentHTML('afterbegin', ` Preferred Deposit Amount <em class="icon ni ni-chevron-right-fill-c"></em> ${currency}`);

        // }

        if (userEmail !== null) {
          userEmail.forEach((e) =>
            e.insertAdjacentHTML('afterbegin', email),
          );
        }
        if (amountDeposit !== null) {
          amountDeposit.forEach((e) =>
            e.insertAdjacentHTML('afterbegin', `${currency}${formatNumberWithCommasAndDecimal(Number(amountDeposited))}`),
          );
        }

        if (userlink !== null) {
          userlink.value = `${sitelink}dashboard/sign-up?u=${userId}`;
        }

        if (userName !== null) {
          userName.forEach((e) =>
            e.insertAdjacentHTML('afterbegin', fullName),
          );
        }
        if (abbrName !== null) {
          const split = fullName.split(" ");
          const initials = split.map(part => part.charAt(0)).join("").toUpperCase();
          abbrName.forEach((e) =>
            e.insertAdjacentHTML('afterbegin', initials),
          );
        }
      }
    })
    .catch(function (error) {
      console.error(error);
    });
  axios
    .get(`../newApi/api/task/fetchUserActivity/${userid}`)
    .then(function (response) {
      if (response.status === 201) {
        const result = response.data.message;
        const activity = result.activity;
        const unreadActivities = activity.filter((e) => e.status !== 'Read');
        unreadActivities.length !== 0
          ? (messagenum.innerHTML = unreadActivities.length)
          : (messagenum.style.display = 'none');
        unreadActivities.length === 0
          ? (message.style.display = 'none')
          : 'new';
        if (bell !== null) {
          unreadActivities.length === 0 ? (bell.style.display = 'none') : '';
        }
      }
    })
    .catch(function (error) {
      if (error.response && error.response.status === 422) {
        const message = error.response.data.errors[0];
        // Toasty.showToast('danger', message);
      }
    });
});
