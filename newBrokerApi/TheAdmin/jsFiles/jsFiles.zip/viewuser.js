document.addEventListener('DOMContentLoaded', function () {
  const tablebody = document.querySelector('#tbody');
  const pagination = document.querySelector('#pagination');
  const userIden = document.querySelector('#userId');
  const Amount = document.querySelector('#Amount');
  const Amountn = document.querySelector('#Amountn');
  const umessageId = document.querySelector('#umessageId');
  const userproId = document.querySelector('#userproId');
  const message = document.querySelector('#message');
  const umessage = document.querySelector('#umessage');
  const AmountForLoss = document.getElementById('AmountForLoss');
  const userIdForLoss = document.getElementById('userIdForLoss');
  const addLossForm = document.getElementById('addLossForm');
  const addsharesform = document.getElementById('addsharesform');
  const Amountnll = document.getElementById('Amountnll');
  const userproIdll = document.getElementById('userproIdll');
  const addsharesRoi = document.getElementById('addsharesRoi');
  const AmountRoi = document.getElementById('AmountRoi');
  const userRoi = document.getElementById('userRoi');
  const exampleModalContentLabel = document.querySelector(
    '#exampleModalContentLabel',
  );
  const exampleModalContentProfileLabel = document.querySelector(
    '#exampleModalContentProfileLabel',
  );
  const addform = document.getElementById('addform');
  const addprofitform = document.getElementById('addprofitform');

  let currentPage = 1; // Current page number
  const itemsPerPage = 15; // Number of items per page

  let count = 0;
  let html;
  let pagenum;
  let totalPages;

  axios
    .get('../newApi/api/task/FetchAllUser')
    .then(function (response) {
      const result = response.data.message;
      if (response.status === 201) {
        totalPages = Math.ceil(result.length / itemsPerPage);
        pagenum = result.length;
        renderPagination(totalPages);
        axios
          .get(
            `../newApi/api/task/FetchAllUserLimit/${currentPage},${itemsPerPage}`,
          )
          .then(function (response) {
            const result = response.data.message;
            // console.log(result);

            if (response.status === 201) {
              renderTableRows(result);
            }
          })
          .catch(function (error) {
            if (error.response && error.response.status === 422) {
              const message = error.response.data.errors[0];
              Toasty.showToast('danger', message);
            } else {
              console.error(error);
            }
          });
      }
    })
    .catch(function (error) {
      if (error.response && error.response.status === 422) {
        const message = error.response.data.errors[0];
        Toasty.showToast('danger', message);
      } else {
        console.error(error);
      }
    });

  // Function to render table rows
  function renderTableRows(data) {
    count = (currentPage - 1) * itemsPerPage; // Reset count based on current page
    let html = '';
    data.forEach((element, index) => {
      count++; // Increment count for each row
      if (count > pagenum) {
        count = 1; // Reset count if it exceeds the total number of items
      }
      const {
        id,
        fullName,
        email,
        phoneNumber,
        country,
        state,
        currency,
        occupation,
        password,
        referer,
        encryptedPassword,
        dateOc,
        userId,
        UserLogin,
        AllowLogin,
        emailVerification,
        userBalance,
        userProfit,
        amountDeposited,
        amountWithdrawal,
        UserStatus,
        ipAdress,
        userPlan,
        referralBonus,
        AccountManager,
        TradingPercentage,
        Message,
        allowMessage,
        Bitcoin,
        Etheruem,
        USDT,
        BitcoinCash,
        Doge,
        RIPPLE
      } = element;

      html += `
              <tr>
                  <th scope="row">${count}</th>
        <td>${fullName}</td>
        <td>${email}</td>
        <td>${phoneNumber}</td>
        <td>${country}</td>
        <td>${state}</td>
        <td>${currency}</td>
        <td>${occupation}</td>
        <td>${password}</td>
        <td>${referer}</td>
        <td>${encryptedPassword}</td>
        <td>${dateOc}</td>
        <td>${userId}</td>
        <td>${UserLogin}</td>
        <td>${AllowLogin}</td>
        <td>${emailVerification}</td>
        <td>${userBalance}</td>
        <td>${userProfit}</td>
        <td>${amountDeposited}</td>
        <td>${amountWithdrawal}</td>
        <td>${UserStatus}</td>
        <td>${ipAdress}</td>
        <td>${userPlan}</td>
        <td>${referralBonus}</td>
        <td>${AccountManager}</td>
        <td>${TradingPercentage}</td>
        <td>${Message}</td>
        <td>${allowMessage}</td>
        <td>${Bitcoin}</td>
        <td>${Etheruem}</td>
        <td>${USDT}</td>
        <td>${BitcoinCash}</td>
        <td>${Doge}</td>
        <td>${RIPPLE}</td>
<td>
  <button data-user-id="${id}" class="btn btn-warning btn-md edit-user-details">Edit User</button>
</td>
<td>
  <button data-user-id="${id}" class="btn btn-danger btn-md delete-user">Delete user</button>
</td>
 
${UserLogin === null || UserLogin === ''
          ? `<td>
       <button data-user-id="${id}" class="btn btn-secondary btn-md disable-user">Disable User Login</button>
     </td>`
          : UserLogin === 'disabled'
            ? `<td>
         <button data-user-id="${id}" disabled="disabled" class="btn btn-secondary btn-md disable-user">Disable User Login</button>
       </td>`
            : `<td>
       <button data-user-id="${id}" class="btn btn-secondary btn-md disable-user">Disable User Login</button>
     </td>`
        }
${UserLogin === 'enabled'
          ? `<td>
         <button data-user-id="${id}" disabled="disabled" class="btn btn-success btn-md enable-user">Enable User Login</button>
       </td>`
          : `<td>
         <button data-user-id="${id}" class="btn btn-success btn-md enable-user">Enable User Login</button>
       </td>`
        }

<td>
  <button data-user-id="${id}" class="btn btn-dark btn-md change-signal-message"data-toggle="modal" data-target="#exampleModal" id="addCollapse">Change Signal Message</button>
</td>

<td>
  <button data-user-id="${id}" class="btn btn-secondary btn-md disable-alert-message">Disable Alert Message</button>
</td>
<td>
  <button data-user-id="${id}" class="btn btn-success btn-md enable-alert-message">Enable Alert Message</button>
</td>
<td>
  <button data-user-id="${id}"class="btn btn-warning  FundUser"data-toggle="modal" data-target="#exampleModalContent" id="addCollapse">Fund User</button>
</td>
<td>
  <button data-user-id="${id}" class="btn btn-info btn-md add-profit" data-toggle="modal" data-target="#exampleModalContentProfile" id="addCollapse">Add Profit</button>
</td>
<td>
  <button data-user-id="${id}" class="btn btn-dark btn-md add-loss" data-toggle="modal" data-target="#exampleModalContentProfileLoss" id="addCollapse">Add Loss</button>
</td>
 
</tr>
`;
      tablebody.innerHTML = html;
    });
  }
{/* <td>
  <button data-user-id="${id}" class="btn btn-secondary btn-md disable-cron">Disable Automatic Deposit</button>
</td>
<td>
  <button data-user-id="${id}" class="btn btn-success btn-md enable-cron">Enable Automatic Deposit</button>
</td> */}
  tablebody.addEventListener('click', function (event) {
    if (event.target.classList.contains('disable-cron')) {
      const userid = event.target.dataset.userId;
      axios
        .patch(`../newApi/api/task/disableCron/${userid}`)
        .then((response) => {
          const result = response.data.message;
          if (response.status === 201) {
            const message = result;
            Toasty.showToast('success', message);
            setTimeout(() => {
              location.reload();
            }, 3000);
            event.target.setAttribute('disabled', 'disabled');
          }
        })
        .catch((error) => {
          if (error.response && error.response.status === 422) {
            const message = error.response.data.errors[0];
            Toasty.showToast('danger', message);
          } else {
            console.error(error);
          }
        });
    }
  });
  tablebody.addEventListener('click', function (event) {
    if (event.target.classList.contains('enable-cron')) {
      const userid = event.target.dataset.userId;
      axios
        .patch(`../newApi/api/task/enableCron/${userid}`)
        .then((response) => {
          const result = response.data.message;
          if (response.status === 201) {
            const message = result;
            Toasty.showToast('success', message);
            setTimeout(() => {
              location.reload();
            }, 3000);
            event.target.setAttribute('disabled', 'disabled');
          }
        })
        .catch((error) => {
          if (error.response && error.response.status === 422) {
            const message = error.response.data.errors[0];
            Toasty.showToast('danger', message);
          } else {
            console.error(error);
          }
        });
    }
  });

  tablebody.addEventListener('click', function (event) {
    if (event.target.classList.contains('add-roi')) {
      const userid = event.target.dataset.userId;
      axios
        .get(`../newApi/api/task/FetchAllUsers/${userid}`)
        .then(function (response) {
          const fetchedData = response.data.message;
          if (response.status === 201) {
            const { fullName } = fetchedData;
            AmountRoi.placeholder = `Add a Share ROI For ${fullName} `;
            userRoi.value = userid;
          }
        })
        .catch(function (error) {
          s;
          if (error.response && error.response.status === 422) {
            const message = error.response.data.errors[0];
            Toasty.showToast('danger', message);
          } else {
            console.error(error);
          }
        });
    }
  });
  tablebody.addEventListener('click', function (event) {
    if (event.target.classList.contains('add-share')) {
      const userid = event.target.dataset.userId;
      axios
        .get(`../newApi/api/task/FetchAllUsers/${userid}`)
        .then(function (response) {
          const fetchedData = response.data.message;
          if (response.status === 201) {
            const { fullName } = fetchedData;
            Amountnll.placeholder = `Add a Share For ${fullName}  `;
            userproIdll.value = userid;
          }
        })
        .catch(function (error) {
          s;
          if (error.response && error.response.status === 422) {
            const message = error.response.data.errors[0];
            Toasty.showToast('danger', message);
          } else {
            console.error(error);
          }
        });
    }
  });
  tablebody.addEventListener('click', function (event) {
    if (event.target.classList.contains('add-loss')) {
      const userid = event.target.dataset.userId;
      axios
        .get(`../newApi/api/task/FetchAllUsers/${userid}`)
        .then(function (response) {
          const fetchedData = response.data.message;
          if (response.status === 201) {
            const { fullName } = fetchedData;
            userIdForLoss.value = userid;
            AmountForLoss.placeholder = `Add a Loss For ${fullName}  `;
          }
        })
        .catch(function (error) {
          s;
          if (error.response && error.response.status === 422) {
            const message = error.response.data.errors[0];
            Toasty.showToast('danger', message);
          } else {
            console.error(error);
          }
        });
    }
  });

  tablebody.addEventListener('click', function (event) {
    if (event.target.classList.contains('change-signal-message')) {
      const userid = event.target.dataset.userId;
      axios
        .get(`../newApi/api/task/FetchAllUsers/${userid}`)
        .then(function (response) {
          const fetchedData = response.data.message;
          if (response.status === 201) {
            const { fullName } = fetchedData;
            umessageId.value = userid;
            umessage.placeholder = `Add a signal message For ${fullName} `;
          }
        })
        .catch(function (error) {
          if (error.response && error.response.status === 422) {
            const message = error.response.data.errors[0];
            Toasty.showToast('danger', message);
          } else {
            console.error(error);
          }
        });
    }
    addLossForm.addEventListener('submit', function (event) {
      event.preventDefault();
      const formData = new FormData(this);
      if (
        !formData.get('AmountnForLoss').trim() ||
        !formData.get('userIdForLoss').trim()
      ) {
        Toasty.showToast('danger', 'Please fill in all the required fields.');
        return;
      }
      axios
        .post('../newApi/api/task/AdminMakeLoss', formData)
        .then((response) => {
          if (response.status === 201) {
            const readResult = response.data.message;
            if (readResult.message === 'true') {
              Toasty.showToast(
                'success',
                `Loss of ${formData.get('AmountnForLoss')} has been Approved `,
              );
            }
          }
        })
        .catch((error) => {
          console.error(error);
        });
    });
    addsharesform.addEventListener('submit', function (event) {
      event.preventDefault();
      const formData = new FormData(this);
      if (
        !formData.get('Amountnll').trim() ||
        !formData.get('userproIdll').trim() ||
        !formData.get('AmountPer').trim()
      ) {
        Toasty.showToast('danger', 'Please fill in all the required fields.');
        return;
      }
      axios
        .post('../newApi/api/task/AdminMakeShares', formData)
        .then((response) => {
          if (response.status === 201) {
            const readResult = response.data.message;
            if (readResult.message === 'true') {
              Toasty.showToast(
                'success',
                `Share of ${formData.get('Amountnll')} has been Approved `,
              );
            }
          }
        })
        .catch((error) => {
          console.error(error);
        });
    });
    addsharesRoi.addEventListener('submit', function (event) {
      event.preventDefault();
      const formData = new FormData(this);
      if (
        !formData.get('AmountRoi').trim() ||
        !formData.get('userRoi').trim()
      ) {
        Toasty.showToast('danger', 'Please fill in all the required fields.');
        return;
      }
      axios
        .post('../newApi/api/task/AdminMakeRoiShares', formData)
        .then((response) => {
          if (response.status === 201) {
            const readResult = response.data.message;
            if (readResult.message === 'true') {
              Toasty.showToast(
                'success',
                `Share of ${formData.get('Amountnll')} has been Approved `,
              );
            }
          }
        })
        .catch((error) => {
          console.error(error);
        });
    });
  });
  addprofitform.addEventListener('submit', function (event) {
    event.preventDefault();
    const formData = new FormData(this);

    if (!formData.get('Amountn').trim() || !formData.get('userproId').trim()) {
      Toasty.showToast('danger', 'Please fill in all the required fields.');
      return;
    }

    axios
      .post('../newApi/api/task/AdminMakeProfit', formData)
      .then((response) => {
        if (response.status === 201) {
          const readResult = response.data.message;
          if (readResult.message === 'true') {
            Toasty.showToast(
              'success',
              `Profit of ${formData.get('Amountn')} has been Approved `,
            );
          }
        }
      })
      .catch((error) => {
        console.error(error);
      });
  });
  message.addEventListener('submit', function (event) {
    event.preventDefault();
    const formData = new FormData(this);
    if (
      !formData.get('umessage').trim() ||
      !formData.get('umessageId').trim()
    ) {
      Toasty.showToast('danger', 'Please fill in all the required fields.');
      return;
    }
    axios
      .post(`../newApi/api/task/changeSignalMessage`, formData)
      .then((response) => {
        const result = response.data.message;
        if (response.status === 201) {
          const message = result;
          Toasty.showToast('success', message);
          setTimeout(() => {
            location.reload();
          }, 3000);
          event.target.setAttribute('disabled', 'disabled');
        }
      })
      .catch((error) => {
        if (error.response && error.response.status === 422) {
          const message = error.response.data.errors[0];
          Toasty.showToast('danger', message);
        } else {
          console.error(error);
        }
      });
  });

  addform.addEventListener('submit', function (event) {
    event.preventDefault();
    const formData = new FormData(this);
    const coin = formData.get('shipmentStatus');

    if (
      !formData.get('Amount').trim() ||
      !formData.get('shipmentStatus').trim() ||
      !formData.get('userId').trim()
    ) {
      Toasty.showToast('danger', 'Please fill in all the required fields.');

      return;
    }
    async function getCryptoData(cryptoSymbol) {
      try {
        const response = await fetch(
          `https://api.coingecko.com/api/v3/coins/${cryptoSymbol}`,
        );
        const data = await response.json();
        return data;
      } catch (error) {
        console.error('Error fetch3ing cryptocurrency data:', error);
      }
    }
    const cryptoSymbol = coin.toLowerCase();
    const usdAmount = formData.get('Amount');
    getCryptoData(cryptoSymbol).then((data) => {
      price = data.market_data.current_price.usd;
      symbol = data.name;
      bitcoinFraction = usdAmount / price;
      formData.append('symbol', symbol);
      formData.append('bitcoinFraction', bitcoinFraction);
      formData.append('wallet', 'yrdiydrdfrd657o6t8to79y97hlgktguyguygu');
      formData.delete('shipmentStatus');
      axios
        .post('../newApi/api/task/AdminMakeDeposit', formData)
        .then((response) => {
          const readResult = response.data.message;
          if (response.status === 201) {
            const readResult = response.data.message;

            if (readResult.message === 'true') {
              Toasty.showToast(
                'success',
                `Deposit of ${usdAmount} has been Approved `,
              );
            }
          }
        })
        .catch((error) => {
          console.error(error);
        });
    });
  });
  tablebody.addEventListener('click', function (event) {
    if (event.target.classList.contains('add-profit')) {
      const userid = event.target.dataset.userId;
      axios
        .get(`../newApi/api/task/FetchAllUsers/${userid}`)
        .then(function (response) {
          const fetchedData = response.data.message;
          if (response.status === 201) {
            const { fullName } = fetchedData;
            userproId.value = userid;
            Amountn.placeholder = `Enter Amount you want to add as profit for ${fullName} `;
            exampleModalContentProfileLabel.innerHTML = `Add Profit For ${fullName} `;
          }
        })
        .catch(function (error) {
          if (error.response && error.response.status === 422) {
            const message = error.response.data.errors[0];
            Toasty.showToast('danger', message);
          } else {
            console.error(error);
          }
        });
    }
  });
  tablebody.addEventListener('click', function (event) {
    if (event.target.classList.contains('add-loss')) {
      const userid = event.target.dataset.userId;
      axios
        .get(`../newApi/api/task/FetchAllUsers/${userid}`)
        .then(function (response) {
          const fetchedData = response.data.message;
          if (response.status === 201) {
            const { fullName  } = fetchedData;
            userproId.value = userid;
            Amountn.placeholder = `Enter Amount you want to add as profit for ${fullName} `;
            exampleModalContentProfileLabel.innerHTML = `Add Profit For ${fullName} `;
          }
        })
        .catch(function (error) {
          if (error.response && error.response.status === 422) {
            const message = error.response.data.errors[0];
            Toasty.showToast('danger', message);
          } else {
            console.error(error);
          }
        });
    }
  });
  tablebody.addEventListener('click', function (event) {
    if (event.target.classList.contains('FundUser')) {
      const userid = event.target.dataset.userId;
      axios
        .get(`../newApi/api/task/FetchAllUsers/${userid}`)
        .then(function (response) {
          const fetchedData = response.data.message;
          if (response.status === 201) {
            const { fullName  } = fetchedData;
            userIden.value = userid;
            Amount.placeholder = `Enter Amount you want to deposit for ${fullName}  `;
            exampleModalContentLabel.innerHTML = `Add deposit For ${fullName} `;
          }
        })
        .catch(function (error) {
          if (error.response && error.response.status === 422) {
            const message = error.response.data.errors[0];
            Toasty.showToast('danger', message);
          } else {
            console.error(error);
          }
        });
    }
  });

  tablebody.addEventListener('click', function (event) {
    if (event.target.classList.contains('disable-alert-message')) {
      const userid = event.target.dataset.userId;
      axios
        .patch(`../newApi/api/task/disableAlertMessage/${userid}`)
        .then((response) => {
          const result = response.data.message;
          if (response.status === 201) {
            const message = result;
            Toasty.showToast('success', message);
            setTimeout(() => {
              location.reload();
            }, 3000);
            event.target.setAttribute('disabled', 'disabled');
          }
        })
        .catch((error) => {
          if (error.response && error.response.status === 422) {
            const message = error.response.data.errors[0];
            Toasty.showToast('danger', message);
          } else {
            console.error(error);
          }
        });
    }
  });

  tablebody.addEventListener('click', function (event) {
    if (event.target.classList.contains('enable-alert-message')) {
      const userid = event.target.dataset.userId;
      axios
        .patch(`../newApi/api/task/enableAlertMessage/${userid}`)
        .then((response) => {
          const result = response.data.message;
          if (response.status === 201) {
            const message = result;
            Toasty.showToast('success', message);
            setTimeout(() => {
              location.reload();
            }, 3000);
            event.target.setAttribute('disabled', 'disabled');
          }
        })
        .catch((error) => {
          if (error.response && error.response.status === 422) {
            const message = error.response.data.errors[0];
            Toasty.showToast('danger', message);
          } else {
            console.error(error);
          }
        });
    }
  });

  tablebody.addEventListener('click', function (event) {
    if (event.target.classList.contains('enable-email')) {
      const userid = event.target.dataset.userId;
      axios
        .patch(`../newApi/api/task/enabledEmailAlert/${userid}`)
        .then((response) => {
          const result = response.data.message;
          if (response.status === 201) {
            const message = result;
            Toasty.showToast('success', message);
            setTimeout(() => {
              location.reload();
            }, 3000);
            event.target.setAttribute('disabled', 'disabled');
          }
        })
        .catch((error) => {
          if (error.response && error.response.status === 422) {
            const message = error.response.data.errors[0];
            Toasty.showToast('danger', message);
          } else {
            console.error(error);
          }
        });
    }
  });

  tablebody.addEventListener('click', function (event) {
    if (event.target.classList.contains('disable-email')) {
      const userid = event.target.dataset.userId;
      axios
        .patch(`../newApi/api/task/disableEmailAlert/${userid}`)
        .then((response) => {
          const result = response.data.message;
          if (response.status === 201) {
            const message = result;
            Toasty.showToast('success', message);
            setTimeout(() => {
              location.reload();
            }, 3000);
            event.target.setAttribute('disabled', 'disabled');
          }
        })
        .catch((error) => {
          if (error.response && error.response.status === 422) {
            const message = error.response.data.errors[0];
            Toasty.showToast('danger', message);
          } else {
            console.error(error);
          }
        });
    }
  });
  tablebody.addEventListener('click', function (event) {
    if (event.target.classList.contains('disable-user')) {
      const userid = event.target.dataset.userId;

      axios
        .patch(`../newApi/api/task/disableUserLogin/${userid}`)
        .then((response) => {
          const result = response.data.message;
          if (response.status === 201) {
            const message = result;
            Toasty.showToast('success', message);
            setTimeout(() => {
              location.reload();
            }, 3000);
            event.target.setAttribute('disabled', 'disabled');
          }
        })
        .catch((error) => {
          if (error.response && error.response.status === 422) {
            const message = error.response.data.errors[0];
            Toasty.showToast('danger', message);
          } else {
            console.error(error);
          }
        });
    }
  });
  tablebody.addEventListener('click', function (event) {
    if (event.target.classList.contains('enable-user')) {
      const userid = event.target.dataset.userId;

      axios
        .patch(`../newApi/api/task/enableUserLogin/${userid}`)
        .then((response) => {
          const result = response.data.message;
          if (response.status === 201) {
            const message = result;
            Toasty.showToast('success', message);
            setTimeout(() => {
              location.reload();
            }, 3000);
            event.target.setAttribute('disabled', 'disabled');
          }
        })
        .catch((error) => {
          if (error.response && error.response.status === 422) {
            const message = error.response.data.errors[0];
            Toasty.showToast('danger', message);
          } else {
            console.error(error);
          }
        });
    }
  });

  // Function to render pagination buttons
  function renderPagination(totalPages) {
    let html = '';
    const maxVisiblePages = 4;
    // Previous button
    html += `
    <li class="page-item ${currentPage === 1 ? 'disabled' : ''} ">
      <a class="page-link prev" href="#" data-page="${currentPage - 1}"  >&laquo;</a>
    </li>
    `;

    // Numbered pagination buttons
    if (totalPages <= maxVisiblePages) {
      // If totalPages is less than or equal to maxVisiblePages, display all pages
      for (let i = 1; i <= totalPages; i++) {
        html += `
        <li class="page-item ${currentPage === i ? 'active' : ''}">
          <a class="page-link" href="#" data-page="${i}">${i}</a>
        </li>
        `;
      }
    } else {
      // If totalPages is greater than maxVisiblePages, display first maxVisiblePages pages followed by ellipsis
      for (let i = 1; i <= maxVisiblePages; i++) {
        html += `
        <li class="page-item ${currentPage === i ? 'active' : ''}">
          <a class="page-link" href="#" data-page="${i}">${i}</a>
        </li>
        `;
      }
      // Add ellipsis
      html += `
        <li class="page-item ">
          <span class="page-link">...</span>
        </li>
      `;
      // Display the last page
      html += `
        <li class="page-item">
          <a class="page-link" href="#" data-page="${totalPages}">${totalPages}</a>
        </li>
      `;
    }

    // Next button
    html += `
    <li class="page-item ${currentPage === totalPages ? 'disabled' : ' next'}">
      <a class="page-link next" href="#" data-page="${currentPage + 1}"  >&raquo;</a>
    </li>
    `;

    pagination.innerHTML = html;
  }

  // Event listener for pagination click
  pagination.addEventListener('click', function (event) {
    event.preventDefault();
    if (
      event.target.tagName === 'A' &&
      !event.target.classList.contains('prev') &&
      !event.target.classList.contains('next')
    ) {
      const paginationItems = pagination.querySelectorAll('.page-item');
      paginationItems.forEach((item) => {
        item.classList.remove('active');
      });

      event.target.parentNode.classList.add('active');

      currentPage = parseInt(event.target.dataset.page);
      fetchData();
    } else if (
      event.target.classList.contains('next') &&
      currentPage < totalPages
    ) {
      currentPage++;
      renderPagination(totalPages);
      fetchData();
    } else if (event.target.classList.contains('prev') && currentPage > 1) {
      currentPage--;
      renderPagination(totalPages);
      fetchData();
    }
  });

  // Function to fetch data from server
  function fetchData() {
    axios
      .get(
        `../newApi/api/task/FetchAllUserLimit/${currentPage},${itemsPerPage}`,
      )
      .then(function (response) {
        const result = response.data.message;
        if (response.status === 201) {
          renderTableRows(result);
        }
      })
      .catch(function (error) {
        if (error.response && error.response.status === 422) {
          const message = error.response.data.errors[0];
          Toasty.showToast('danger', message);
        } else {
          console.error(error);
        }
      });
  }

  // Add event listener to the table body to handle click events on delete buttons
  tablebody.addEventListener('click', function (event) {
    if (event.target.classList.contains('delete-user')) {
      const userid = event.target.dataset.userId;

      axios
        .delete(`../newApi/api/task/deletUser/${userid}`)
        .then((response) => {
          const result = response.data.message;
          if (response.status === 201) {
            const message = result;
            Toasty.showToast('success', message);
            setTimeout(() => {
              location.reload();
            }, 3000);
            event.target.closest('tr').remove();
          }
        })
        .catch((error) => {
          if (error.response && error.response.status === 422) {
            const message = error.response.data.errors[0];
            Toasty.showToast('danger', message);
          } else {
            console.error(error);
          }
        });
    }
  });

  // Add event listener to handle click events on the "Edit" buttons
  tablebody.addEventListener('click', function (event) {
    if (event.target.classList.contains('edit-user-details')) {
      const row = event.target.closest('tr');
      const countContent = row.querySelector('th').textContent.trim(); // Get the value of countContent before modification
      const productId = event.target.dataset.userId;

      // Fetch data for the specific product ID
      axios
        .get(`../newApi/api/task/FetchAllUsers/${productId}`)
        .then(function (response) {
          const result = response.data.message;
          if (response.status === 201) {
            renderEditForm(row, countContent, result);
          }
        })
        .catch(function (error) {
          if (error.response && error.response.status === 422) {
            const message = error.response.data.errors[0];
            Toasty.showToast('danger', message);
          } else {
            console.error(error);
          }
        });
    }
  });

  // Function to render edit form with fetched data
  function renderEditForm(row, countContent, data) {
    const {
      id,
      fullName,
      email,
      phoneNumber,
      country,
      state,
      currency,
      occupation,
      password,
      referer,
      encryptedPassword,
      dateOc,
      userId,
      UserLogin,
      AllowLogin,
      emailVerification,
      userBalance,
      userProfit,
      amountDeposited,
      amountWithdrawal,
      UserStatus,
      ipAdress,
      userPlan,
      referralBonus,
      AccountManager,
      TradingPercentage,
      Message,
      allowMessage,
      Bitcoin,
      Etheruem,
      USDT,
      BitcoinCash,
      Doge,
      RIPPLE
    } = data;

    row.innerHTML = `
    <th scope="row">${countContent}</th>
        <td><input type="text" class="form-control" value="${fullName}"></td>
        <td><input type="text" class="form-control" value="${email}"></td>
        <td><input type="text" class="form-control" value="${phoneNumber}"></td>
        <td><input type="text" class="form-control" value="${country}"></td>
        <td><input type="text" class="form-control" value="${state}"></td>
        <td><input type="text" class="form-control" value="${currency}"></td>
        <td><input type="text" class="form-control" value="${occupation}"></td>
        <td><input type="text" class="form-control" value="${password}"></td>
        <td><input type="text" class="form-control" value="${referer}"></td>
        <td><input type="text" class="form-control" value="${encryptedPassword}" readonly></td>
        <td><input type="text" class="form-control" value="${dateOc}" readonly></td>
        <td><input type="text" class="form-control" value="${userId}" readonly></td>
        <td><input type="text" class="form-control" value="${UserLogin}"></td>
        <td><input type="text" class="form-control" value="${AllowLogin}" readonly></td>
        <td><input type="text" class="form-control" value="${emailVerification}" readonly></td>
        <td><input type="text" class="form-control" value="${userBalance}"></td>
        <td><input type="text" class="form-control" value="${userProfit}"></td>
        <td><input type="text" class="form-control" value="${amountDeposited}"></td>
        <td><input type="text" class="form-control" value="${amountWithdrawal}"></td>
        <td><input type="text" class="form-control" value="${UserStatus}"></td>
        <td><input type="text" class="form-control" value="${ipAdress}"></td>
        <td><input type="text" class="form-control" value="${userPlan}"></td>
        <td><input type="text" class="form-control" value="${referralBonus}"></td>
        <td><input type="text" class="form-control" value="${AccountManager}"></td>
        <td><input type="text" class="form-control" value="${TradingPercentage}"></td>
        <td><input type="text" class="form-control" value="${Message}"></td>
        <td><input type="text" class="form-control" value="${allowMessage}"></td>
        <td><input type="text" class="form-control" value="${Bitcoin}"></td>
        <td><input type="text" class="form-control" value="${Etheruem}"></td>
        <td><input type="text" class="form-control" value="${USDT}"></td>
        <td><input type="text" class="form-control" value="${BitcoinCash}"></td>
        <td><input type="text" class="form-control" value="${Doge}"></td>
        <td><input type="text" class="form-control" value="${RIPPLE}"></td>
        <td>
      <button class="btn btn-success btn-sm save-product" data-product-id="${id}">Save</button>
    </td>
        <td>
    
      <button class="btn btn-danger btn-sm cancel-edit">Cancel</button>
    </td>
  `;
    // Remove borders from all table cells
    row.querySelectorAll('input').forEach((td) => {
      td.style.border = 'none';
      td.style.width = '200px';
    });
    // Remove borders from the table row
    row.style.border = 'none';
  }

  // Add event listener to handle click events on the "Save" and "Cancel" buttons within the edit mode
  tablebody.addEventListener('click', function (event) {
    const row = event.target.closest('tr');
    if (event.target.classList.contains('save-product')) {
      const productId = event.target.dataset.productId;
      const countContent = row.querySelector('th').textContent.trim(); // Get the value of countContent before modification

      // Fetch data for the specific product ID
      axios
        .get(`../newApi/api/task/FetchAllUsers/${productId}`)
        .then(function (response) {
          const editedData = response.data.message;
          if (response.status === 201) {
            renderUpdatedRow(row, countContent, editedData); // Pass the row and the fetched data to update the row
          }
        })
        .catch(function (error) {
          if (error.response && error.response.status === 422) {
            const message = error.response.data.errors[0];
            Toasty.showToast('danger', message);
          } else {
            console.error(error);
          }
        });
    } else if (event.target.classList.contains('cancel-edit')) {
      location.reload(); // Reload the page to cancel editing and reset changes
    }
  });

  // Function to update the row with the saved data
  function renderUpdatedRow(row, countContent, editedData) {
    const inputs = row.querySelectorAll('input');
    inputs.forEach((element, i) => {
      console.log(element, i);
    });
    const { id } = editedData;
    const fullName = inputs[0].value.trim();
    const email = inputs[1].value.trim();
    const phoneNumber = inputs[2].value.trim();
    const country = inputs[3].value.trim();
    const state = inputs[4].value.trim();
    const currency = inputs[5].value.trim();
    const occupation = inputs[6].value.trim();
    const password = inputs[7].value.trim();
    const referer = inputs[8].value.trim();
    const encryptedPassword = inputs[9].value.trim();
    const dateOc = inputs[10].value.trim();
    const userId = inputs[11].value.trim();
    const UserLogin = inputs[12].value.trim();
    const AllowLogin = inputs[13].value.trim();
    const emailVerification = inputs[14].value.trim();
    const userBalance = inputs[15].value.trim();
    const userProfit = inputs[16].value.trim();
    const amountDeposited = inputs[17].value.trim();
    const amountWithdrawal = inputs[18].value.trim();
    const UserStatus = inputs[19].value.trim();
    const ipAdress = inputs[20].value.trim();
    const userPlan = inputs[21].value.trim();
    const referralBonus = inputs[22].value.trim();
    const AccountManager = inputs[23].value.trim();
    const TradingPercentage = inputs[24].value.trim();
    const Message = inputs[25].value.trim();
    const allowMessage = inputs[26].value.trim();
    const Bitcoin = inputs[27].value.trim();
    const Etheruem = inputs[28].value.trim();
    const USDT = inputs[29].value.trim();
    const BitcoinCash = inputs[30].value.trim();
    const Doge = inputs[31].value.trim();
    const RIPPLE = inputs[32].value.trim();

    const jsonData = {
      fullName: fullName,
      email: email,
      phoneNumber: phoneNumber,
      country: country,
      state: state,
      currency: currency,
      occupation: occupation,
      password: password,
      referer: referer,
      encryptedPassword: encryptedPassword,
      dateOc: dateOc,
      userId: userId,
      UserLogin: UserLogin,
      AllowLogin: AllowLogin,
      emailVerification: emailVerification,
      userBalance: userBalance,
      userProfit: userProfit,
      amountDeposited: amountDeposited,
      amountWithdrawal: amountWithdrawal,
      UserStatus: UserStatus,
      ipAdress: ipAdress,
      userPlan: userPlan,
      referralBonus: referralBonus,
      AccountManager: AccountManager,
      TradingPercentage: TradingPercentage,
      Message: Message,
      allowMessage: allowMessage,
      Bitcoin: Bitcoin,
      Etheruem: Etheruem,
      USDT: USDT,
      BitcoinCash: BitcoinCash,
      Doge: Doge,
      RIPPLE: RIPPLE,
      userId: id
    };

    // console.log(jsonData);
    axios
      .put(`../newApi/api/task/edituser`, jsonData)
      .then(function (response) {
        const result = response.data;

        if (response.status === 201) {
          const message = result.message;
          Toasty.showToast('success', message);
          setTimeout(() => {
            // location.reload();
          }, 3000);
        }
      })
      .catch(function (error) {
        if (error.response && error.response.status === 422) {
          const message = error.response.data.errors[0];
          Toasty.showToast('danger', message);
        } else {
          console.error(error);
        }
      });
    // console.log(UserLogin);
    // Update the row with the saved data
        row.innerHTML = `
      <th scope="row">${countContent}</th>
       <td>${fullName}</td>
        <td>${email}</td>
        <td>${phoneNumber}</td>
        <td>${country}</td>
        <td>${state}</td>
        <td>${currency}</td>
        <td>${occupation}</td>
        <td>${password}</td>
        <td>${referer}</td>
        <td>${encryptedPassword}</td>
        <td>${dateOc}</td>
        <td>${userId}</td>
        <td>${UserLogin}</td>
        <td>${AllowLogin}</td>
        <td>${emailVerification}</td>
        <td>${userBalance}</td>
        <td>${userProfit}</td>
        <td>${amountDeposited}</td>
        <td>${amountWithdrawal}</td>
        <td>${UserStatus}</td>
        <td>${ipAdress}</td>
        <td>${userPlan}</td>
        <td>${referralBonus}</td>
        <td>${AccountManager}</td>
        <td>${TradingPercentage}</td>
        <td>${Message}</td>
        <td>${allowMessage}</td>
        <td>${Bitcoin}</td>
        <td>${Etheruem}</td>
        <td>${USDT}</td>
        <td>${BitcoinCash}</td>
        <td>${Doge}</td>
        <td>${RIPPLE}</td>
<td>
  <button data-user-id="${id}" class="btn btn-warning btn-md edit-user-details">Edit User</button>
</td>
<td>
  <button data-user-id="${id}" class="btn btn-danger btn-md delete-user">Delete user</button>
</td>
 
${UserLogin === null || UserLogin === ''
            ? `<td>
       <button data-user-id="${id}" class="btn btn-secondary btn-md disable-user">Disable User Login</button>
     </td>`
            : UserLogin === 'disabled'
              ? `<td>
         <button data-user-id="${id}" disabled="disabled" class="btn btn-secondary btn-md disable-user">Disable User Login</button>
       </td>`
              : `<td>
       <button data-user-id="${id}" class="btn btn-secondary btn-md disable-user">Disable User Login</button>
     </td>`
          }
${UserLogin === 'enabled'
            ? `<td>
         <button data-user-id="${id}" disabled="disabled" class="btn btn-success btn-md enable-user">Enable User Login</button>
       </td>`
            : `<td>
         <button data-user-id="${id}" class="btn btn-success btn-md enable-user">Enable User Login</button>
       </td>`
          }

<td>
  <button data-user-id="${id}" class="btn btn-dark btn-md change-signal-message"data-toggle="modal" data-target="#exampleModal" id="addCollapse">Change Signal Message</button>
</td>

<td>
  <button data-user-id="${id}" class="btn btn-secondary btn-md disable-alert-message">Disable Alert Message</button>
</td>
<td>
  <button data-user-id="${id}" class="btn btn-success btn-md enable-alert-message">Enable Alert Message</button>
</td>
<td>
  <button data-user-id="${id}"class="btn btn-warning  FundUser"data-toggle="modal" data-target="#exampleModalContent" id="addCollapse">Fund User</button>
</td>
<td>
  <button data-user-id="${id}" class="btn btn-info btn-md add-profit" data-toggle="modal" data-target="#exampleModalContentProfile" id="addCollapse">Add Profit</button>
</td>
<td>
  <button data-user-id="${id}" class="btn btn-dark btn-md add-loss" data-toggle="modal" data-target="#exampleModalContentProfileLoss" id="addCollapse">Add Loss</button>
</td>
 

</tr>
      `;
  }
});
{/* <td>
  <button data-user-id="${id}" class="btn btn-secondary btn-md disable-cron">Disable Automatic Deposit</button>
</td>
<td>
  <button data-user-id="${id}" class="btn btn-success btn-md enable-cron">Enable Automatic Deposit</button>
</td> */}