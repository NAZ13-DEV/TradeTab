document.addEventListener('DOMContentLoaded', function () {
    // const from = document.querySelector("#from");
    // const to = document.querySelector("#to");
    // const currency = localStorage.getItem('currency')
 
    // console.log(from, to);
});