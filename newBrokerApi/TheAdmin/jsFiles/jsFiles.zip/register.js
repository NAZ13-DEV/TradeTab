const ValidationArra = [
  {
    selector: 'input[name="fname"]',
    pattern: /^[a-zA-Z]+$/,
    errorMEssage: "First Name Must Contain No Space",
  },
  {
    selector: 'input[name="lname"]',
    pattern: /^[a-zA-Z]+$/,
    errorMEssage: "Last Name Must Contain No Space",
  },

  {
    selector: 'input[name="email"]',
    pattern: /^[\w.-]+@[a-zA-Z\d.-]+\.[a-zA-Z]{2,}$/i,
    errorMEssage: "Email Address Is Invalid",
  },

  {
    selector: 'input[name="username"]',
    pattern: /^[a-zA-Z0-9_-]{3,16}$/,
    errorMEssage:
      "Username Must Be Between 3 And 16 Characters And Special Characters Are Not Allowed Except The _",
  },

  {
    selector: 'input[name="pnum"]',
    pattern: /^\+\d{10,13}$/,
    errorMEssage:
      "Invalid Phone Number Format Number Must Be In This Format (+12244547778)",
  },
  {
    selector: 'input[name="password"]',
    pattern: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[_\W])[\s\S]{8,16}$/,
    errorMEssage:
      "Password Must Contain One Lowercase Letter, One Uppercase Letter, One Digit And One Special Character ",
  },
  {
    selector: 'input[name="cpassword"]',
    pattern: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[_\W])[\s\S]{8,16}$/,
    errorMEssage:
      "Confirm Password Must Contain One Lowercase Letter, One Uppercase Letter, One Digit And One Special Character  ",
  },
];

const submitButton = document.querySelector("button[class='btn-style-1']");
const form = document.querySelector("#registration-form");
let item;
let Error;
let requestData = {};
const validateOnInputListener = function (
  selectedElement,
  validationPattern,
  errorMessage
) {
  implementValidationOnInput(
    selectedElement,
    validationPattern,
    errorMessage,
    submitButton
  );
  const clickedElement = document.querySelector(selectedElement);
  clickedElement.addEventListener("input", function (e) {
    // console.log(clickedElement.value);
    e.preventDefault();
    implementValidationOnInput(
      selectedElement,
      validationPattern,
      errorMessage,
      submitButton
    );
    if (clickedElement.value === "") {
      showError(selectedElement, "This Field is required");
      unSetLoader(submitButton, "Register");
    }

    if (!validationPattern.test(clickedElement.value)) {
      Error = true;
      submitButton.disabled = true;
      const errorMessageElement = document.querySelector(".errorMessage");
      if (errorMessageElement) {
        submitButton.disabled = true;
      }
    } else {
      Error = false;
    }
  });
  clickedElement.addEventListener("paste", function (e) {
    e.preventDefault();
    implementValidationOnInput(
      selectedElement,
      validationPattern,
      errorMessage,
      submitButton
    );
    if (!validationPattern.test(clickedElement.value)) {
      Error = true;
      submitButton.disabled = true;
      const errorMessageElement = document.querySelector(".errorMessage");
      if (errorMessageElement) {
        submitButton.disabled = true;
      }
    } else {
      if (error.response && error.response.status === 422) {
        const message = error.response.data.errors[0];
        toastr["error"](message);
      }
    }
  });
};
const validateInputFields = function (ValidationArray) {
  ValidationArray.forEach((items) => {
    validateOnInputListener(
      items.selector,
      items.pattern,
      items.errorMEssage,
      submitButton
    );
  });
};

validateInputFields(ValidationArra);

form.addEventListener("submit", function (e) {
  e.preventDefault();
  // console.log(e);
  setLoader(submitButton);
  setTimeout(function () {
    ValidationArra.forEach((items, ind) => {
      try {
        const Allselector = document.querySelector(items.selector);

        if (Allselector.value === "") {
          showError(items.selector, "This Field is required");
          unSetLoader(submitButton, "Register");
        }
        // hideError(items.selector);
        const impli = implementValidationOnInput(
          items.selector,
          items.pattern,
          items.errorMEssage,
          submitButton
        );
        item = items.selector;
        const pattern = items.pattern;

        if (pattern.test(Allselector.value) === true) {
          Error = false;
        } else if (pattern.test(Allselector.value) === false) {
          Error = true;
          submitButton.setAttribute("disabled", "disabled");
          const errorMessageElement = document.querySelector(".errorMessage");
          if (errorMessageElement) {
            submitButton.disabled = true;
          }
        }
        const Allselectors = document.querySelectorAll(item);
        Allselectors.forEach((selector) => {
          // console.log(selector);
          if (selector.value === "") {
            unSetLoader(submitButton, "Register");
            error = true;
          } else {
            error = false;
            setLoader(submitButton);
          }
        });
      } catch (error) {
        if (error.response && error.response.status === 422) {
          const message = error.response.data.errors[0];
          toastr["error"](message);
        }
      }
    });
    const formData = new FormData(form);

    if (Error === false) {
      axios
        .post("newApi/api/task/reguser", formData)
        .then(function (response) {
          const result = response.data;
          if (response.status === 201) {
            const message = result.message;
            toastr["success"](message);
          }
        })
        .catch(function (error) {
          if (error.response && error.response.status === 422) {
            const message = error.response.data.errors[0];
            toastr["error"](message);
          }
        })
        .finally(function () {
          unSetLoader(submitButton, "Register");
        });
    }
  }, 2500);
});
